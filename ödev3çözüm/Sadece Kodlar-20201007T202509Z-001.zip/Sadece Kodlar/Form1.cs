﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ders3_Ödev1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
           if(textBox1.Text==""||textBox2.Text==""|| textBox3.Text == ""||textBox4.Text == ""||textBox5.Text==""|| textBox6.Text == "" || textBox7.Text == "" || comboBox1.Text==""|| comboBox2.Text == "" || comboBox3.Text == "" || comboBox4.Text == "")
            {
                MessageBox.Show("Lütfen eksik bilgi girmeyiniz!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                double fizik, kimya, biyoloji, mat, fkatsayi, kkatsayi, bkatsayi, mkatsayi, ortalama;

                fizik = Convert.ToDouble(textBox4.Text);
                kimya = Convert.ToDouble(textBox5.Text);
                biyoloji = Convert.ToDouble(textBox6.Text);
                mat = Convert.ToDouble(textBox7.Text);
                fkatsayi = Convert.ToDouble(comboBox1.Text);
                kkatsayi = Convert.ToDouble(comboBox2.Text);
                bkatsayi = Convert.ToDouble(comboBox3.Text);
                mkatsayi = Convert.ToDouble(comboBox4.Text);

                if (fizik <= 100 && fizik >= 0 && kimya <= 100 && kimya >= 0 && mat <= 100 && mat >= 0 && biyoloji <= 100 && biyoloji >= 0&&fkatsayi>0&&kkatsayi>0&&bkatsayi>0&&mkatsayi>0) 
                {

                    listBox1.Items.Add(textBox1.Text);
                    listBox2.Items.Add(textBox2.Text);
                    listBox3.Items.Add(textBox3.Text);

                    ortalama = (fizik * fkatsayi + kimya * kkatsayi + biyoloji * bkatsayi + mat * mkatsayi) / (fkatsayi + kkatsayi + bkatsayi + mkatsayi);

                    listBox4.Items.Add(ortalama.ToString());
                    if (ortalama >= 85)
                    {
                        listBox5.Items.Add("PEKİYİ");
                    }
                    else if (ortalama < 85 && ortalama >= 70)
                    {
                        listBox5.Items.Add("İYİ");
                    }
                    else if (ortalama < 70 && ortalama >= 55) 
                    {
                        listBox5.Items.Add("ORTA");
                    }
                    else if (ortalama < 55 && ortalama >= 45)
                    {
                        listBox5.Items.Add("GEÇER");
                    }
                    else if (ortalama < 45 && ortalama >= 25)
                    {
                        listBox5.Items.Add("GEÇMEZ");
                    }
                    else
                    {
                        listBox5.Items.Add("ETKİSİZ");
                    }
                    MessageBox.Show("İşlem tamamlanmıştır.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Lütfen not değerlerinin ve katsayı değerlerinin istenilen aralıkta olduğundan emin olunuz.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            textBox7.Clear();
            comboBox1.Text = "";
            comboBox2.Text = "";
            comboBox3.Text = "";
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.ExitThread();
        }
    }
}
